var tool = function(){
}

export default tool;